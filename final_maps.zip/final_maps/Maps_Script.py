
#Final_Script
import requests
from bs4 import BeautifulSoup
import pandas as pd
from fake_useragent import UserAgent
import time

# Generate a fake user agent
user_agent = UserAgent().random

# Set headers with the fake user agent
headers = {
    'User-Agent': user_agent,
    'Accept-Language': 'en-US,en;q=0.5',
}

# Initialize empty lists to store company names and links
all_company_name1 = []
all_company_names = []
all_company_links = []

# Loop through each page (assuming 12 pages in this case)
for page in range(1, 13):
    # Modify the URL to include the page number
    url = f"https://www.google.com/search?sca_esv=585445638&tbs=lf:1,lf_ui:2&tbm=lcl&sxsrf=AM9HkKlWztXowrT648F5OEde0hebAuAQjQ:1701021135358&q=real+estate+agent+in+Jasola&rflfq=1&num=20&start={20 * (page - 1)}"

    # Send a GET request to the URL with headers
    response = requests.get(url, headers=headers)
    print(response)

    # Parse the HTML content of the page using BeautifulSoup
    soup = BeautifulSoup(response.text, 'html.parser')

    # Find all div elements with class name 'dbg0pd'
    company_divs = soup.find_all('div', class_='VkpGBb')

    # Extract company names and links from all div elements on this page
    for company_div in company_divs:
        # Extract company name
        company_name = company_div.text.strip()
        all_company_names.append(company_name)

        # Extract link
        link_tag = company_div.find('a', href=True)
        if link_tag:
            company_link = link_tag['href']
            all_company_links.append(company_link)
        else:
            all_company_links.append(None)
            
    company_divs1=soup.find_all("div",class_='dbg0pd')
    
    for company_div1 in company_divs1:
        company_name1 = company_div1.text.strip()
        all_company_name1.append(company_name1)
    
    # Adding a delay of 1 second
    time.sleep(5)

# Save the results to an Excel file
data = {'Company Name': all_company_names, 'Company Link': all_company_links, 'Company Name1':all_company_name1}
df = pd.DataFrame(data)

print(df.head())

df['Company Name'] = df['Company Name'].astype(str)  # Ensure the column is treated as string
print(df)
# Split the 'text' column into five columns based on the "·" delimiter
df[['col1', 'col2', 'col3', 'col4', 'col5']] = df['Company Name'].str.split('·', expand=True)

columns_to_clean = ['col3','col4', 'col5']

# Define a function to extract only numeric values
def extract_numeric(value):
    try:
        return float(''.join(filter(str.isdigit, str(value))))
    except ValueError:
        return float('nan')  # or any default value you prefer

# Apply the function to each cell in the specified columns
for column in columns_to_clean:
    df[column] = df[column].apply(extract_numeric)
print(df)

##
df = df[(df['col3'].astype(str).apply(len) >= 10) | (df['col4'].astype(str).apply(len) >= 10)]

# If you want to reset the index after removing rows
df = df.reset_index(drop=True)


df['col3'] = df['col3'].astype(str)

# Replace values with less than 10 digits with 0
df['col3'] = df['col3'].apply(lambda x: '0' if len(x) < 10 else x)

# Convert back to numeric if needed
df['col3'] = pd.to_numeric(df['col3'])
def extract_last_10_digits(value):
    return str(value)[-12:]

# Apply the function to the specified columns
df['col3'] = df['col3'].apply(extract_last_10_digits)
df['col4'] = df['col4'].apply(extract_last_10_digits)


df['col4']=df['col4'].replace('nan',0)

df['col5']= df['col3'].astype(float) + df['col4'].astype(float)




df['col2','col3','col4'].drop(inplace=True)
column1_values = df['Company Name'].astype(str)
column2_values = df['Company Name1'].astype(str)

# Iterate over each row and check for matching words
for index, row in df.iterrows():
    for word in column2_values:
        if word in column1_values.iloc[index]:
            df.at[index, 'Company Name1'] = word
            break  # Break the loop if a match is found


df.to_excel('final.xlsx', index=False)